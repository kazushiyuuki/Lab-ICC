void zerarTab(char ** tab, int n);
void player(char ** tab, char c,int *x, int * y);
void cpu(char ** tab,int n, char c, int jogadas,int *x, int * y);
int verificar(char ** tab,int x, int y, int n,int min,char c, int jogador);
void rendertab(char ** tab,int n);
void freemat(int n, char **v);